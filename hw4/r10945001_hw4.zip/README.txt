執行r10945001_hw4.py

參考資料:
Self-Attention Pooling: https://stackoverflow.com/questions/69778483/converting-from-pytorch-to-tensorflow-for-self-attention-pooling-layer
Additive Margin Softmax: https://github.com/tomastokar/Additive-Margin-Softmax