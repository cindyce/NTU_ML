# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 14:55:28 2022

@author: yupei
"""

import pandas as pd
import os
import csv

import math
import numpy as np
    
path = os.getcwd()
# List files
files = os.listdir(path)
files_csv = [f for f in files if f[:6] == 'result']

data_num = len(files_csv)
data_length = 4957
data_count = data = pd.DataFrame(index=list(range(data_length)), columns=list(range(data_num)))

i = 0
for f in files_csv:
    data = pd.read_csv(f, encoding='UTF-8')
    #data_count = data_count.append(data['Answer'])
    data_count[i] = data['Answer']
    i += 1


result = []
for j in range(data_length):
    freq = data_count.loc[j,:].value_counts()
    ans = freq.idxmax()
    result.append(ans)
with open('result.csv', 'w', encoding='UTF-8') as f:
    f.write('ID,Answer\n')
    for i, y in enumerate(result):
        f.write(f"{i},{result[i].replace(',','')}\n")

