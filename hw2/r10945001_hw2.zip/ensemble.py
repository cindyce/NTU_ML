# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 14:55:28 2022

@author: yupei
"""

import pandas as pd
import os
import csv

import math
import numpy as np
    
path = os.getcwd()
# List files
files = os.listdir(path)
files_csv = [f for f in files if f[:10] == 'prediction']

data_num = len(files_csv)
data_length = 646268
data_count = np.zeros([data_length, data_num]).astype(int)

i = 0
for f in files_csv:
    data = pd.read_csv(f)
    data_count[:,i] = data['Class']
    i += 1

#ensemble_prediction = np.zeros([data_length, 1]).astype(int)
ensemble_prediction = np.array([], dtype=np.int32)
for j in range(data_length):
    #ensemble_prediction[j,:] = np.argmax(np.bincount(data_count[j,:]))
    #ensemble_prediction = np.concatenate((ensemble_prediction,result), axis=0)
    result = np.argmax(np.bincount(data_count[j,:]))
    ensemble_prediction = np.append(ensemble_prediction, result)
#ensemble_prediction = list(ensemble_prediction)
with open('ensemble prediction.csv', 'w') as f:
    f.write('Id,Class\n')
    for i, y in enumerate(ensemble_prediction):
        f.write('{},{}\n'.format(i, y))