# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 22:47:50 2022

@author: G2
"""

import os
from PIL import Image

path = './results/styleGAN'
# List files
files = os.listdir(path)
imgs = [f for f in files if f.startswith("generated") & f.endswith("ema.jpg")]

os.makedirs('styleGAN_output', exist_ok=True)
for i in range(len(imgs)):
    img = Image.open(os.path.join(path, imgs[i]), mode='r')
    img = img.resize((64, 64))
    img.save(f'styleGAN_output/{i+1}.jpg')
    